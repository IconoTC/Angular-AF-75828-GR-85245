import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  texto: string = "Bienvenidos al curso de Angular";
  numero: number = 756754321.7543315;
  porcentaje: number = 0.54578754;

  // Funiciona de diferentes formas
  fecha: Date = new Date();
  //fecha: Date = new Date('8/25/2025');  // mes/dia/año
  //fecha: string = '8/25/2025';

  persona: Object = {
    nombre: "Pepito",
    "apellido": "Perez",
    edad: 37,
    telefonos: {
      tel1: 915237842,
      tel2: 616123456
    }
  };
}
