export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyCGqMfLT34BGM-tDJ2F9yCJH-db3Dw8SIs",
    authDomain: "anabel-angular-24-octubre.firebaseapp.com",
    projectId: "anabel-angular-24-octubre",
    storageBucket: "anabel-angular-24-octubre.firebasestorage.app",
    messagingSenderId: "652656999761",
    appId: "1:652656999761:web:d24b2f9c3123b3eefd6770"
  }
};
