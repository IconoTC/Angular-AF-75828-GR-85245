import { TranslateService } from '@ngx-translate/core';
import { Pipe, PipeTransform } from '@angular/core';

// pure: false es para que ejecute el transform() por cada value recibido
@Pipe({
  name: 'estado',
  pure: false  
})
export class EstadoPipe implements PipeTransform {

  constructor(private translateService: TranslateService){}

  transform(value: unknown, ...args: unknown[]): unknown {
    
    if (value){
      return this.translateService.instant("pipe.abierto");
    } else {
      return this.translateService.instant("pipe.cerrado");
    }
  }

}
