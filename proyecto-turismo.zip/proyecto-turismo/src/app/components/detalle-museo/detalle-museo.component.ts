import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalle-museo',
  templateUrl: './detalle-museo.component.html',
  styleUrls: ['./detalle-museo.component.css']
})
export class DetalleMuseoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
