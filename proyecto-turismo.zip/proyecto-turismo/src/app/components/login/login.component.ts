import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent{

  email: string = '';
  pw: string = '';
  confPw: string = '';
  registro: boolean = false;

  constructor(private loginService: LoginService) { }

  login(){
    this.loginService.login(this.email, this.pw)
      .then(() => {})
      .catch((error)=>{
        console.log(error);
        alert("Credenciales no validas o no estas registrado");
      })
  }

  registrarme(){
    if (this.pw == this.confPw){
      this.loginService.registro(this.email, this.pw)
        .then(() => {
          alert("Usuario registrado");
        })
        .catch(error => {
          console.log(error)
        })
    } else {
      alert("El password y la confirmacion no son iguales");
    }
  }
}
