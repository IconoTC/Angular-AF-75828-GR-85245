import { Directive, ElementRef, HostBinding, HostListener, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appContarClicks]'
})
export class ContarClicksDirective {

  numeroClicks: number = 0;

  @HostBinding('style.opacity')
  opacidad: number = 0.1;

  @HostBinding('style.font-size')  // Tambien funciona style.fontSize
  size:string = '';

  constructor(private renderer: Renderer2, private elRef: ElementRef) { }

  @HostListener('click')
  procesarClicks(): void{
    this.numeroClicks++;
    this.opacidad += 0.1;
    this.size = (15 + this.numeroClicks + "px");

    let contenidoAnterior = this.elRef.nativeElement.innerHTML;
    let nuevoContenido = contenidoAnterior + " " + this.numeroClicks;
    this.elRef.nativeElement.innerHTML = nuevoContenido;
  }

}
