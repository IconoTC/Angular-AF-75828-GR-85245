import { Component } from '@angular/core';
import { AgendaService } from './services/agenda.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  amigos: any[] = [];
  id: string = '';
  contacto: any;
  mostrar: boolean = false;

  amigoForm = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')]),
  });

  constructor(private agendaService: AgendaService){
    agendaService.getAll().subscribe(datos => {
      // limpiar la lista de amigos
      this.amigos = [];
      datos.forEach(item => {
        this.amigos.push(item.payload.doc.data())
      })
    });
  }

  modificar(){
    this.agendaService.modicarAmigo(this.id, this.amigoForm.value)
      .then( () => {
        this.mostrar = false;   // ocultar el formulario
        this.contacto = null;   // ocultar el contacto encontrado
        this.id = '';   // limpiar el campo del formulario
        this.amigoForm.reset();
        alert("Contacto modificado");
      })
      .catch(error => {
        console.log(error);
      })
  }

  editar(){
    this.amigoForm.setValue(this.contacto);
    this.mostrar = true;
  }

  borrar(){
    this.agendaService.eliminarAmigo(this.id)
      .then( () => {
        this.id = '';  // limpiar el campo del formulario
        this.contacto = null;   // ocultar el contacto encontrado
        alert("Contacto eliminado");
      })
      .catch(error => {
        console.log(error);
      })     
  }

  buscar(){
    this.agendaService.buscarAmigo(this.id).subscribe(item => {
      this.contacto = item.payload.data();
    });
  }

  alta(){
    this.agendaService.nuevoAmigo(this.amigoForm.value)
      .then( () => {
        // limpiar el formulario
        this.amigoForm.reset();
        alert("Contacto creado");
      })
      .catch( error => {
        console.log(error);
      }) 
  }
  
}
